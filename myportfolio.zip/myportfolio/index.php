<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>portfolio of Billy Panshak</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/venobox/venobox.css" rel="stylesheet">
  <link href="assets/vendor/owl.carousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
</head>

<body>

  <!-- ======= Mobile nav toggle button ======= -->
  <button type="button" class="mobile-nav-toggle d-xl-none"><i class="icofont-navigation-menu"></i></button>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="d-flex flex-column">

      <div class="profile">
        <img src="assets/img/profile-img.jpg" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><a href="index.php">Billy Panshak Shippi</a></h1>
        <div class="social-links mt-3 text-center">
          <a href="https://twitter.com/shippi_billy" target="_blank" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="https://github.com/billypanshak" target="_blank" class="github"><i class="bx bxl-github"></i></a>
          <a href="https://web.facebook.com/billypanshak" target="_blank" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="https://www.instagram.com/billy_panshak" target="_blank" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="https://join.skype.com/invite/b90lcmcuFXH3" target="_blank" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="https://www.linkedin.com/in/billy-panshak-shippi-a43793138" target="_blank" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

      <nav class="nav-menu">
        <ul>
          <li class="active"><a href="index.php"><i class="bx bx-home"></i> <span>Home</span></a></li>
          <li><a href="#about"><i class="bx bx-user"></i> <span>About</span></a></li>
          <li><a href="#resume"><i class="bx bx-file-blank"></i> <span>Resume</span></a></li>
          <li><a href="#portfolio"><i class="bx bx-book-content"></i> Portfolio</a></li>
          <li><a href="#services"><i class="bx bx-server"></i> Services</a></li>
          <li><a href="#contact"><i class="bx bx-envelope"></i> Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->
      <button type="button" class="mobile-nav-toggle d-xl-none"><i class="icofont-navigation-menu"></i></button>

    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
      <h3 font style="color:white">My name is</h3>
      <h1>Billy Panshak Shippi</h1>
      <p>I'm a <span class="typed" data-typed-items="Computer Scientist, Fullstack Web Developer, Cross-platform App Developer, System Analyst, Cyber Security Specialist, Freelancer, Teacher, Singer"></span></p>
    </div>
  </section><!-- End Hero -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>About</h2>
          <p>My name is Billy Panshak Shippi. I was born to the family of Late Sgt. Billy Shippi and Mrs. Elizabeth Billy Shippi in Nyelleng Village
            of Fier District, Pankshin Local Government Area of Plateau State Nigeria.
          </p>
        </div>

        <div class="row">
          <div class="col-lg-4" data-aos="fade-right">
            <img src="assets/img/profile-img.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
            <h3> Certified Computer Scientist;</h3>
            <p class="font-italic">
              with proficiency in: Fullstack Web Development using scripting languages like PHP, JavaScript, HTML, CSS and Frameworks like Laravel, Visual
              Studio, WordPress/Bootstrap Templates; Computer Programming with specialty in Languages like Java, Python, native C, C++ and C#. I also specialise
              in developing Cross-platform mobile apps using IDEs like Android Studio, Xamarin Studio and Visual Studio. Finally, I'm Proficient in Database 
              Administration using Structured Query Language (SQL) 
            </p>
            <div class="row">
              <div class="col-lg-6">
                <ul>
                  <!--<li><i class="icofont-rounded-right"></i> <strong>Birthday:</strong> 2nd February, 1995</li>-->
                  <li><i class="icofont-rounded-right"></i> <strong>Website:</strong>https://churchconnect.org.ng/billypanshak</li>
                  <li><i class="icofont-rounded-right"></i> <strong>Phone:</strong> +234 8100549569</li>
                  <li><i class="icofont-rounded-right"></i> <strong>City:</strong> Jos : Plateau State, Nigeria</li>
                </ul>
              </div>
              <div class="col-lg-6">
                <ul>
                  <!--<li><i class="icofont-rounded-right"></i> <strong>Age:</strong> 26</li>-->
                  <li><i class="icofont-rounded-right"></i> <strong>Degree:</strong> Bsc. Computer Science</li>
                  <li><i class="icofont-rounded-right"></i> <strong>Email:</strong>billypanshak@gmail.com</li>
                  <li><i class="icofont-rounded-right"></i> <strong>Freelance:</strong> Available</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Facts Section ======= -->
    <section id="facts" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Facts</h2>
        </div>
        <div class="row no-gutters">
          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="count-box">
              <i class="icofont-document-folder"></i>
              <span data-toggle="counter-up">10</span>
              <p><strong>Projects </strong><a href="https://github.com/billypanshak" target="_blank" class="github"><i class="bx bxl-github"></i>check out the project/Work I have done so far</a></p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="count-box">
              <i class="icofont-download"></i>
              <p><strong>Download my Vcard</strong></p>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Facts Section -->

    <!-- ======= Skills Section ======= -->
    <section id="skills" class="skills section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Skills</h2>
        </div>

        <div class="row skills-content">

          <div class="col-lg-6" data-aos="fade-up">

            <div class="progress">
              <span class="skill">HTML <i class="val">100%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">CSS <i class="val">90%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">JavaScript <i class="val">65%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <div class="progress">
              <span class="skill">PHP/MYSQL <i class="val">60%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <div class="progress">
              <span class="skill">Bootstrap, WordPress/CMS <i class="val">90%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <div class="progress">
              <span class="skill">JAVA <i class="val">60%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <div class="progress">
              <span class="skill">PYTHON <i class="val">60%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <div class="progress">
              <span class="skill">C# <i class="val">50%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <div class="progress">
              <span class="skill">C <i class="val">45%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <div class="progress">
              <span class="skill">C++ <i class="val">50%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Skills Section -->
    <!-- ======= Resume Section ======= -->
    <section id="resume" class="resume">
      <div class="container">
        <div class="section-title">
          <h2>Resume</h2>
        </div>
        <div class="row">
          <div class="col-lg-6" data-aos="fade-up">
            <h3 class="resume-title">Sumary</h3>
            <div class="resume-item pb-0">
              <h4>Billy Panshak Shippi</h4>
              <p><em>A goal-oriented Computer Scientist, highly self-motivated, innovative, and able to take on leadership responsibilities
                and consistently deliver on set goals; with 3+ years of experience in computer Programming, web and mobile app user-centered development. Strong analytical background
              and structured problem-solving skills</em></p>
              <ul>
                <li>COCIN LCC Mado, Tudun Wada, P.O.Box 6564, Anglo - Jos, Jos.</li>
                <li>(+234) 8100549569</li>
                <li>billypanshak@gmail.com</li>
              </ul>
            </div>

            <h3 class="resume-title">Education</h3>
            <div class="resume-item">
              <h4>Bachelor of Science in Computer Science</h4>
              <h5>2013 - 2018</h5>
              <p><em>University of Jos Nigeria</em></p>
            </div>
            <div class="resume-item">
              <h4>Senior School Certificate; National Examination Council (NECO)</h4>
              <h5>2006 - 2012</h5>
              <p><em>Excellence International Academy Tudun Wada Jos, Plateau State</em></p>
            </div>
            <div class="resume-item">
              <h4>Primary School Leaving Certificate</h4>
              <h5>2000 - 2006</h5>
              <p><em>Army Children School Rukuba Barracks, Bassa LGA Plateau State</em></p>
            </div>
          </div>
          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
            <h3 class="resume-title">Professional Membership/Experience</h3>
            <div class="resume-item">
              <h4>Computer Professional Body of Nigeria</h4>
              <h5>2019 - Present</h5>
            </div>
            <div class="resume-item">
              <h4>Corps Liaison Officer (CLO)/Biometric Database Administrator </h4>
              <h5>2018 - 2019</h5>
              <p><em>National Youth Service Corp (NYSC) at Nnewi South LGA of Anambra State, Nigeria </em></p>
              <ul>
                <li>Installed and configured monthly biometric capturing software in preparation for NYSC's monthly corps members clearance</li>
                <li>Gathered and verified data of corps members from the biometric app for quarterly report. </li>
              </ul>
            </div>
            <div class="resume-item">
              <h4>Computer Science Teacher</h4>
              <h5>2018 - 2019</h5>
              <p><em>Union Secondary School Amichi, Nnewi South LGA of Anambra State, Nigeria</em></p>
              <ul>
                <li>Managed and taught up to 150 students the aspect of Computer Science at the Secondary school level while under pressure</li>
                <li>Created Lesson Plans for effective teaching</li>
                <li>Configured and reinstalled Windows Operating System on 50 laptops in preparation for students practicals on Database Management, Word Processing,
                  Graphics Design and the Usage of the Internet
                </li>
              </ul>
            </div>
            <div class="resume-item">
              <h4>IT Student  </h4>
              <h5>2016 - 2017</h5>
              <p><em>Corporate Information Services (CIS); ICT Directorate, University of Jos. </em></p>
              <ul>
                <li>Installed a Database Management Software in preparation for student online admission screening.</li>
                <li>Configured systems in preparation for Android Mobile development.</li>
                <li>Developed a user – centered website using scripting languages for data capturing. </li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Resume Section -->

    <!-- ======= Portfolio Section ======= -->
    <section id="portfolio" class="portfolio section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Portfolio</h2>
          <p>Below are some of the  projects I have done and hosted/deployed so far</p>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">App</li>
              <li data-filter=".filter-web">Web</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-1.png" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-1.png" data-gall="portfolioGallery" class="venobox" title="App 1"><i class="bx bx-plus"></i></a>
                <a href="mobileportfolio-details.php" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-2.png" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-2.png" data-gall="portfolioGallery" class="venobox" title="Web 3"><i class="bx bx-plus"></i></a>
                <a href="webportfolio-details.php" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-3.png" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-3.png" data-gall="portfolioGallery" class="venobox" title="App 2"><i class="bx bx-plus"></i></a>
                <a href="mobileportfolio-details.php" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-5.png" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-5.png" data-gall="portfolioGallery" class="venobox" title="Web 2"><i class="bx bx-plus"></i></a>
                <a href="webportfolio-details.php" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-6.png" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-6.png" data-gall="portfolioGallery" class="venobox" title="App 3"><i class="bx bx-plus"></i></a>
                <a href="mobileportfolio-details.php" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="assets/img/portfolio/portfolio-9.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="assets/img/portfolio/portfolio-9.jpg" data-gall="portfolioGallery" class="venobox" title="Web 3"><i class="bx bx-plus"></i></a>
                <a href="webportfolio-details.php" title="More Details"><i class="bx bx-link"></i></a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Portfolio Section -->

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container">

        <div class="section-title">
          <h2>Services</h2>
          <p>I render the following services effectively. Feel free to contact me when the need arises.</p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up">
            <div class="icon"><i class="icofont-computer"></i></div>
            <h4 class="title"><a href="">Web Development</a></h4>
            <p class="description">involves creating, uploading and maintaining websites for clients</p>
          </div>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100">
            <div class="icon"><i class="icofont-phone"></i></div>
            <h4 class="title"><a href="">Mobile App Development</a></h4>
            <p class="description">cross-platform inclined; any area as the case might be</p>
          </div>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="200">
            <div class="icon"><i class="icofont-teacher"></i></div>
            <h4 class="title"><a href="">Tutoring/Teaching</a></h4>
            <p class="description">involves teaching/tutoring on the aspect of Computer Programming, Web/Mobile App Development, Computer Appreciation
              on the aspect of: word processing using Microsoft word, databasing using Microsoft Access, Data analysis using Excel and preliminary Graphics Design
              using Corel Draw
            </p>
          </div>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="300">
            <div class="icon"><i class="icofont-network"></i></div>
            <h4 class="title"><a href="">Freelancing</a></h4>
            <p class="description"></p>
          </div>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="400">
            <div class="icon"><i class="icofont-live-support"></i></div>
            <h4 class="title"><a href="">IT Support</a></h4>
            <p class="description">in terms of software installations, System Maintenance and Repairs</p>
          </div>
          <div class="col-lg-4 col-md-6 icon-box" data-aos="fade-up" data-aos-delay="500">
            <div class="icon"><i class="icofont-shopping-cart"></i></div>
            <h4 class="title"><a href="">Marketing</a></h4>
            <p class="description">using existing powerful electronic tools(Email Marketing tools, Web Development
              tools, Social Media Campaigning tools, etc) to create online brand promotion, presence and patronization</p>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Testimonials</h2>
          <p>These are some of the testimonies from my clients</p>
        </div>

        <div class="owl-carousel testimonials-carousel">

          <div class="testimonial-item" data-aos="fade-up">
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              He is highly analytical, straightforward(honest and direct) and very inquisitive. He is a programming instructor and a hustler. Principled
              tenacious and dogged in achieving a goal. I have leanrt so much from him and still learning
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
            <img src="assets/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
            <h3>Daniel Nagari</h3>
            <h4>Mathematics Teacher(07036231867)</h4>
          </div>

          <div class="testimonial-item" data-aos="fade-up" data-aos-delay="100">
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              Most of the applications you design are wow. You are indeed deligent in your work
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
            <img src="assets/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
            <h3>Israel Dabet</h3>
            <h4>CEO of Eazy Built Consult(08036567976)</h4>
          </div>

          <div class="testimonial-item" data-aos="fade-up" data-aos-delay="200">
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              When it comes to online marketing, Billy Panshak is just wow. He has given my products(unisex clothings and shoes) online recognition and patronage.Currently,
              am planning on paying him to develop a website for me to market my products
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
            <img src="assets/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
            <h3>Maureen Obeta</h3>
            <h4>CEO NK's Collection(07068447579)</h4>
          </div>

          <div class="testimonial-item" data-aos="fade-up" data-aos-delay="300">
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              Well, I will say Billy is indeed a deligent, creative and deliverable software developer. I once hired him on some mobile and web applications
              (Immunization Record Tracker, Weather Index App, etc); he worked to my satisfaction
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
            <img src="assets/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
            <h3>David Oguche</h3>
            <h4>Assistant Lecturer at University of Jos(09032303313)</h4>
          </div>

          <div class="testimonial-item" data-aos="fade-up" data-aos-delay="400">
            <p>
              <i class="bx bxs-quote-alt-left quote-icon-left"></i>
              I connected Billy to the organization wanting to use the PolishedArrow app and to my surprise, he gave them an intuitive and user-centered
              design
              <i class="bx bxs-quote-alt-right quote-icon-right"></i>
            </p>
            <img src="assets/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
            <h3>Emmanuel I.</h3>
            <h4>Software Developer @ Corporate Information Services (CIS); ICT Directorate, University of Jos(07035473090)</h4>
          </div>

        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Contact</h2>
          <p>You can contact me through my details  or leave a message via the form provided below</p>
        </div>

        <div class="row" data-aos="fade-in">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="icofont-google-map"></i>
                <h4>Location:</h4>
                <p>COCIN LCC Mado, Tudun Wada, P.O.Box 6564, Anglo - Jos, Jos.</p>
              </div>

              <div class="email">
                <i class="icofont-envelope"></i>
                <h4>Email:</h4>
                <p>billypanshak@gmail.com</p>
              </div>

              <div class="phone">
                <i class="icofont-phone"></i>
                <h4>Call:</h4>
                <p>+234 8100549569</p>
              </div>

              <iframe src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d7860.851459010922!2d8.860415403857278!3d9.898455284007674!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x105373149f852a3d%3A0x333377e5450c4eba!2sCOCIN%20LCC%20Mado%2C%20Tudun%20Wada%2C%20Mado%20Tudun%20Wada%2C%20Jos!3m2!1d9.8978099!2d8.863705999999999!5e0!3m2!1sen!2sng!4v1612732486064!5m2!1sen!2sng" frameborder="0" style="border:0; width: 100%; height: 290px;" allowfullscreen></iframe>
            </div>

          </div>

          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
            <form name="message-form" action="forms/contact.php" method="post" role="form" class="php-email-form" id="message-form">
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Your Name</label>
                  <input type="text" name="name" class="form-control" id="name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                  <div class="validate"></div>
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Your Email</label>
                  <input type="email" class="form-control" name="email" id="email" data-rule="email" data-msg="Please enter a valid email" />
                  <div class="validate"></div>
                </div>
              </div>
              <div class="form-group">
                <label for="name">Subject</label>
                <input type="text" class="form-control" name="subject" id="subject" data-rule="minlen:4" data-msg="Please enter a subject/topic for your message" />
                <div class="validate"></div>
              </div>
              <div class="form-group">
                <label for="name">Message</label>
                <textarea class="form-control" name="message" id="message" rows="10" data-rule="required" data-msg="Please write something for us"></textarea>
                <div class="validate"></div>
              </div>
              <div class="mb-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!
                </div>
              </div>
              <div class="text-center">
                <button type="submit">Send Message</button>
              </div>
            </form>
          </div>
        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
       <!--&copy; Copyright <strong><span>iPortfolio</span></strong>-->
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/ -->
        <!--Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>-->
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/jquery/jquery.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/jquery.easing/jquery.easing.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  <script src="assets/vendor/counterup/counterup.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/venobox/venobox.min.js"></script>
  <script src="assets/vendor/owl.carousel/owl.carousel.min.js"></script>
  <script src="assets/vendor/typed.js/typed.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>